package presentation.menu.worlds;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class WorldSelectionView extends BorderPane {
	Button world1;
	Button world2;
	Button world3;
	Label title;
	
	public WorldSelectionView() {
		HBox center = new HBox();
		
		title = new Label();
		
		world1 = new Button();
		world2 = new Button();
		world3 = new Button();
		world1.getStyleClass().add("button-Style-start");
		world2.getStyleClass().add("button-Style-start");
		world3.getStyleClass().add("button-Style-start");
		center.setAlignment(Pos.CENTER);
		center.setSpacing(150);
		
		
		center.getChildren().addAll(world1,world2,world3);
		this.setCenter(center);
		this.getStyleClass().add("window-Style");
	}
}
