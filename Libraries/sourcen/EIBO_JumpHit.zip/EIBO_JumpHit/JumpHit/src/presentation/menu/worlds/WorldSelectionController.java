package presentation.menu.worlds;

import application.Main;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import presentation.ViewController;
import presentation.components.backbutton.BackButtonController;
import presentation.menu.levels.LevelSelectionController;
import presentation.menu.levels.LevelSelectionView;

public class WorldSelectionController extends ViewController {
	private Button world1;
	private Button world2;
	private Button world3;
	private Label title;
	private BackButtonController back;
	private WorldSelectionView view;
	
	private Main main;
	
	public WorldSelectionController(Main main) {
		view = new WorldSelectionView();
		this.main = main;
		back = new BackButtonController(main);
		
		world1 = view.world1;
		world2 = view.world2;
		world3 = view.world3;
		title = view.title;
		rootView = view;
		
		initialize();
	}

	@Override
	public void initialize() {
		
		title.setText("Welten");
		
		HBox top = new HBox();
		top.getChildren().addAll(back.getRootView(), title);
		view.setTop(top);

		world1.addEventHandler(ActionEvent.ACTION, event -> {
			main.createScene(new LevelSelectionController(main,1), Main.Scenes.LEVELMENU);
			main.setLastScene(Main.Scenes.WORLDMENU);
			main.switchScene(Main.Scenes.LEVELMENU);
		});
	}
}
