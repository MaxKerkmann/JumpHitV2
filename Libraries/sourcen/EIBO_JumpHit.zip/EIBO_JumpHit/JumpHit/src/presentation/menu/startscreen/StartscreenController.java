package presentation.menu.startscreen;

import application.Main;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import presentation.ViewController;
import presentation.menu.worlds.WorldSelectionController;

public class StartscreenController extends ViewController {
	private Button startButton;
	private Button infoButton;
	private StartscreenView view;
	private Main main;

	public StartscreenController(Main main) {
		view = new StartscreenView();
		this.main = main;

		startButton = view.startButton;
		infoButton = view.infoButton;

		rootView = view;
		
		initialize();
	}

	@Override
	public void initialize() {
		startButton.setText("Start");
		infoButton.setText("Info");
		
		startButton.addEventHandler(ActionEvent.ACTION, event -> {
			main.createScene(new WorldSelectionController(main), application.Main.Scenes.WORLDMENU);
			main.setLastScene(application.Main.Scenes.STARTSCENE);
			main.switchScene(application.Main.Scenes.WORLDMENU);
		});
	}
}
