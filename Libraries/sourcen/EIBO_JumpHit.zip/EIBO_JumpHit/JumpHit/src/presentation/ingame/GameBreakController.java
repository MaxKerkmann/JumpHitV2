package presentation.ingame;

import application.Main;
import buisness.gamelogic.GamePlayer;
import buisness.gamelogic.finishedMode;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import presentation.ViewController;
import presentation.uicomponents.PlatformSprite;

public class GameBreakController extends ViewController {

    private Button levelSelection;
    private Button repeatLevel;
    private Button nextLevel;
    private Rectangle animation;
    private Main main;
    private GameBreakView view;
    private Stage stage;
    private InGameView gameView;

    public GameBreakController(Main main, InGameView gameView){
        this.main = main;
        view = new GameBreakView();
        this.gameView = gameView;
        levelSelection = view.levelSelection;
        repeatLevel =view.repeatLevel;
        nextLevel = view.nextLevel;
        animation = view.animation;

        rootView = view;

        initialize();
    }

    @Override
    public void initialize() {

        repeatLevel.setText("Repeat");
        repeatLevel.getStyleClass().add("button-Style");

        levelSelection.setText("Levels");
        levelSelection.getStyleClass().add("button-Style");

        nextLevel.setText("Next");
        nextLevel.getStyleClass().add("button-Style");
        if(main.getGamePlayer().getGameState().get() != finishedMode.WON){
            nextLevel.setDisable(true);
        }

        nextLevel.addEventHandler(ActionEvent.ACTION, event -> {

        });

        levelSelection.addEventHandler(ActionEvent.ACTION, event -> {
            main.getGamePlayer().getTimer().stop();
            main.getGamePlayer().cleanPlayField();
            main.switchScene(Main.Scenes.LEVELMENU);
            main.setGamePlayer(new GamePlayer());
            stage.close();
        });

        repeatLevel.addEventHandler(ActionEvent.ACTION, event -> {
            for(Node node : gameView.getChildren()) {
                if (node instanceof Pane) {
                    for (Node platform : (((Pane) node).getChildren())) {
                        if (platform instanceof PlatformSprite) {
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    ((Pane) node).getChildren().remove(platform);
                                }
                            });

                        }
                    }
                }
            }
            main.getGamePlayer().restart();
            stage.close();
        });



    }

    public void showStage() {
        Stage stage = new Stage();
        stage.initStyle(StageStyle.UNDECORATED);
        this.stage = stage;

        Scene newScene = new Scene(this.getRootView());
        stage.setScene(newScene);

        stage.show();
    }


}
