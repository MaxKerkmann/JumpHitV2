package presentation.ingame;

import application.Main;
import buisness.gameElements.Platform;
import buisness.gamelogic.GameObject;
import buisness.gamelogic.GamePlayer;
import buisness.gamelogic.SoundPlayer;
import buisness.gamelogic.finishedMode;
import de.hsrm.mi.eibo.simpleplayer.SimpleAudioPlayer;
import de.hsrm.mi.eibo.simpleplayer.SimpleMinim;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import presentation.ViewController;
import presentation.uicomponents.FrogSprite;
import presentation.uicomponents.PlatformSprite;

public class InGameController extends ViewController {
    private Rectangle leftBorder;
    private Rectangle rightBorder;
    private Rectangle centerBackground;
    private Rectangle safetyBird;
    private InGameView view;
    private Pane playfield;
    private Main main;
    private GamePlayer player;
    private GameBreakController gameBreakController;
    private FrogSprite frogSprite;
    private SoundPlayer soundPlayer;

    SimpleObjectProperty currentPlatform;
    SimpleObjectProperty<finishedMode> gameState;
    SimpleBooleanProperty gameStarted;

    public InGameController(Main main){
        soundPlayer = new SoundPlayer();
        view = new InGameView();
        this.main = main;
        player = main.getGamePlayer();
        currentPlatform = player.getPlatformCounter();
        gameState = player.getGameState();
        gameStarted = player.getGameStarted();

        playfield = view.playfield;
        leftBorder = view.leftBorder;
        rightBorder = view.rightBorder;
        centerBackground = view.centerBackground;
        safetyBird = view.safetyBird;

        rootView = view;


        initialize();

        playfield.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(mouseEvent.getTarget() instanceof Circle){
                    PlatformSprite temp = (PlatformSprite) mouseEvent.getTarget();
                    temp.setFill(Color.GREEN);

                    player.getFrog().setCurrentPlatform((Platform) temp.gameObjectProperty().get());
                    playfield.getChildren().remove(frogSprite);
                    playfield.getChildren().add(frogSprite);


                    Platform platformObject =(Platform) temp.gameObjectProperty().get();

                    if(platformObject.getClicked()==false) {
                        String note = platformObject.getNote();
                        int duration = platformObject.getDuration();
                        SimpleMinim minim = new SimpleMinim();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
//                                SimpleAudioPlayer audioPlayer = minim.loadMP3File("ressources\\sounds\\FART.mp3");
//                                audioPlayer.play();
                                  soundPlayer.toPlay(note,duration);
                            }
                        }).start();

                        platformObject.setClicked();
                    }

                }else{
                    player.getGameState().set(finishedMode.LOST);
                }

            }
        });

        currentPlatform.addListener(new ChangeListener<GameObject>() {
            @Override
            public void changed(ObservableValue<? extends GameObject> observable, GameObject oldValue, GameObject newValue) {

                PlatformSprite pSprite = new PlatformSprite();
                pSprite.setFill(Color.RED);
                pSprite.setRadius(64);
                pSprite.setCenterX(300);
                pSprite.setCenterY(10);
                pSprite.gameObjectProperty().set(newValue);
                player.addToSprites(pSprite);
                playfield.getChildren().add(pSprite);

            }
        });

        gameState.addListener(new ChangeListener<finishedMode>() {
            @Override
            public void changed(ObservableValue<? extends finishedMode> observable, finishedMode oldValue, finishedMode newValue) {
                if (newValue == finishedMode.PLAYING) {
                    view.getChildren().remove(view.getChildren().size()-1);
                } else{
                    Rectangle cover = new Rectangle(1280, 720);
                    cover.setFill(Color.GRAY);
                    cover.setOpacity(0.5);
                    view.getChildren().add(cover);
                    gameBreakController = new GameBreakController(main, view);
                    gameBreakController.showStage();
            }
            }
        });

        gameStarted.addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                if(newValue){
                    frogSprite = new FrogSprite();
                    frogSprite.setHeight(64);
                    frogSprite.setWidth(64);
                    frogSprite.gameObjectProperty().setValue(player.getFrog());
                    player.addToSprites(frogSprite);
                    playfield.getChildren().add(frogSprite);
                    frogSprite.setX(600);
                    frogSprite.setY(200);
                }
            }
        });
    }

    @Override
    public void initialize() {
        leftBorder.setFill(Color.GREEN);
        rightBorder.setFill(Color.GREEN);
        centerBackground.setFill(Color.BLUE);
        safetyBird.setFill(Color.WHITE);


    }
}
