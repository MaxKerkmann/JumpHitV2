package presentation.uicomponents;

import buisness.gamelogic.GameObject;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.io.FileInputStream;


public class FrogSprite extends Rectangle implements SimpleSprite {
    private SimpleObjectProperty<GameObject> gameObject;

    public FrogSprite(){
        gameObject = new SimpleObjectProperty<>();
        Image img = null;
        try {
            img = new Image(new FileInputStream("ressources/game/character/frog.png"));
        }catch (Exception e){

        }
         this.setFill(new ImagePattern(img));


        gameObject.addListener(new ChangeListener<GameObject>() {
            @Override
            public void changed(ObservableValue<? extends GameObject> observable, GameObject oldValue, GameObject newValue) {
                render();
            }
        });
    }

    @Override
    public void render() {
        GameObject model = this.gameObject.get();
        if (model != null) {
            this.setX(model.getX());
            this.setY(model.getY());
        }


    }
    @Override
    public double getYCoord() {
        return this.getY();
    }

    @Override
    public SimpleObjectProperty<GameObject> gameObjectProperty() {
        return gameObject;
    }
}

