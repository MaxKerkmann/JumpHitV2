package buisness.gameElements;

import buisness.gamelogic.GameObject;


//Plattformen mit Attributen
public class Platform implements GameObject {
    private String note;
    private int duration;
    private int position;
    private int passTime;
    private double pauseTime;

    private int fallingSpeed;
    private boolean clicked;

    private double x;
    private double y;
    private int rotation;

    public Platform(String note,int duration, int position, int passTime, double pauseTime){
        this.note = note;
        this.duration = duration;
        this.position = position;
        this.pauseTime = pauseTime;
        this.passTime = passTime;
        fallingSpeed = calculateFallingSpeed();

    }

    private int calculateFallingSpeed(){
        return 200;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y){
        this.y = y;
    }

    public double getPauseTime(){
        return pauseTime;
    }

    public void setPauseTime(double newPauseTime){
        pauseTime = newPauseTime;
    }

    public String getNote(){
        return note;
    }

    public int getDuration() {
        return duration;
    }

    public void setClicked(){
        clicked = true;
    }

    public boolean getClicked(){
        return clicked;
    }

    @Override
    public double getX() {
        return x;
    }

    @Override
    public double getY() {
        return y;
    }

    @Override
    public double getRotation() {
        return rotation;
    }

    @Override
    public void update(double multi) {
        y = y + (fallingSpeed*multi);
    }
}
