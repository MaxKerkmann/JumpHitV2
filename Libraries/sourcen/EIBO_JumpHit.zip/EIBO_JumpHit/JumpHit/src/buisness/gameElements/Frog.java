package buisness.gameElements;

import buisness.gamelogic.GameObject;

//Frosch-Klasse
public class Frog implements GameObject {

    Platform currentPlatform;
    private double x;
    private double y;
    private double rotation;

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y){
        this.y = y;
    }

    @Override
    public double getX() {
        return x;
    }

    @Override
    public double getY() {
        return y;
    }

    @Override
    public double getRotation() {
        return rotation;
    }

    @Override
    public void update(double multi) {
        if(currentPlatform != null){
        x = currentPlatform.getX()-32;
        y = currentPlatform.getY()-32;
        }
    }

    public void setCurrentPlatform(Platform platform){
        currentPlatform = platform;
    }
}
