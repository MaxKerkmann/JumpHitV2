package buisness.gamelogic;

import buisness.gameElements.Platform;
import buisness.gamelogic.GameObject;

import java.util.ArrayList;

//Verwaltung der einzelen GameObjekte
public class GameWorld {
    private ArrayList<GameObject> gameObjects = new ArrayList<>();

    public void add(GameObject object) {
        gameObjects.add(object);
    }

    public void remove(int index){
        gameObjects.remove(index);
    }

    public void removeAll(){
        for(int i = 0;i < gameObjects.size(); i++){
            gameObjects.remove(i);
        }
    }

    //Führt bei jedem GameObjekt in der Liste, die Update aus und schaut ob eine Platform ungeklickt den Bildschirm verlässt und gibt dementsprechend den neuen GameState zurück
    public finishedMode update(double multi) {
        finishedMode gameFinished = finishedMode.PLAYING;
        boolean couldWin = true;
        for(GameObject gameObject : gameObjects){
            gameObject.update(multi);

            if(gameObject instanceof Platform) {
                Platform temp = (Platform) gameObject;
                if (gameObject.getY() > 760 && temp.getClicked() == false) {
                    gameFinished = finishedMode.LOST;
                }
                if (gameObject.getY() < 760){
                    couldWin = false;
                }
            }
        }
        if(couldWin)
            gameFinished = finishedMode.WON;
        return gameFinished;
    }
}
