package buisness.gamelogic;

public enum finishedMode {
    LOST, WON, PLAYING
}
